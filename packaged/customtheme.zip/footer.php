        </div>

        <?php get_template_part( 'template-parts/footer/widgets' ); ?>
        <?php get_template_part( 'template-parts/footer/info' ); ?>
        <?php wp_footer(); ?>
    </body>
</html>