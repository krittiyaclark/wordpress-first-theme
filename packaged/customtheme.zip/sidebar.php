<aside role="complementary">
    <!-- add sidebar after add sidebars.php function -->
    <?php dynamic_sidebar( 'primary-sidebar'); ?>
</aside>