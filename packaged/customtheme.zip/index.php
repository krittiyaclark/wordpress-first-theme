<?php get_header(); ?>

<?php if(have_posts()) { ?>
    <?php while(have_posts()) { ?>
        <?php the_post(); ?>
        <h2>
            <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
        </h2>
        <div>
            <?php customtheme_posts_meta(); ?>
        </div>
        <div>
            <?php the_excerpt(); ?>
        </div>
            <?php customtheme_readmore_link(); ?>
        <?php } ?>
        <?php the_posts_pagination(); ?>
        <?php do_action('customtheme_after_pagination'); ?>
<?php } else { ?> 
    <p><?php echo apply_filters('customtheme_no_posts_text', esc_html__('Sorry, no posts matched your criteria.', 'customtheme')); ?></p>
<?php } ?>

<?php get_footer(); ?>
