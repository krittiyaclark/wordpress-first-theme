<?php
function customtheme__pluginname_admin_scripts( ) {
    global $pagenow;
    if( $pagenow !== 'post.php') return;
    wp_enqueue_script( 'customtheme-_pluginname-admin-scripts', plugins_url( 'customtheme-metaboxes/dist/assets/js/admin.js' ), array( 'jquery' ), '1.0.0', true);
    wp_enqueue_style( 'customtheme-_pluginname-admin-stylesheet',  plugins_url('customtheme-metaboxes/dist/assets/css/admin.css'), array(), '1.0.0', 'all' );
}
add_action( 'admin_enqueue_scripts', 'customtheme__pluginname_admin_scripts' );