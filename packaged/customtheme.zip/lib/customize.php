<?php 
function customtheme_customize_register( $wp_customize ) {
	$wp_customize->get_setting('blogname')->transport = 'postMessage';
	$wp_customize->selective_refresh->add_partial('blogname', array(
        // 'settings' => array('blogname')
        'selector' => '.c-header__blogname',
        'container_inclusive' => false,
        'render_callback' => function() {
            bloginfo( 'name' );
        }
    ));

    /*################## GENERAL SETTINGS ########################*/
    
    $wp_customize->add_section('customtheme_general_options', array(
        'title' => esc_html__( 'General Options', 'customtheme' ),
        'description' => esc_html__( 'You can change general options from here.', 'customtheme' )
    ));
    $wp_customize->add_setting('customtheme_accent_colour', array(
        'default' => '#20ddae',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'customtheme_accent_colour', array(
        'label' => __( 'Accent Color', 'customtheme' ),
        'section' => 'customtheme_general_options',
    )));

    /*################## FOOTER SETTINGS ########################*/

    $wp_customize->selective_refresh->add_partial('customtheme_footer_partial', array(
        'settings' => array('customtheme_footer_bg','customtheme_footer_layout'),
        'selector' => '#footer',
        'container_inclusive' => false,
        'render_callback' => function() {
            get_template_part( 'template-parts/footer/widgets' );
            get_template_part( 'template-parts/footer/info' );
        }
    ));
	$wp_customize->add_section('customtheme_footer_options', array(
        'title' => esc_html__( 'Footer Options', 'customtheme' ),
        'description' => esc_html__( 'You can change footer options from here.', 'customtheme' )
    ));
    $wp_customize->add_setting('customtheme_site_info', array(
        'default' => '',
        'sanitize_callback' => 'customtheme_sanitize_site_info',
        'transport' => 'postMessage'
    ));
    $wp_customize->add_control('customtheme_site_info', array(
        'type' => 'text',
        'label' => esc_html__( 'Site Info', 'customtheme' ),
        'section' => 'customtheme_footer_options'
    ));
    $wp_customize->add_setting('customtheme_footer_bg', array(
        'default' => 'dark',
        'transport' => 'postMessage',
        'sanitize_callback' => 'customtheme_sanitize_footer_bg'
    ));
    $wp_customize->add_control('customtheme_footer_bg', array(
        'type' => 'select',
        'label' => esc_html__( 'Footer Background', 'customtheme' ),
        'choices' => array(
            'light' => esc_html__( 'Light', 'customtheme' ),
            'dark' => esc_html__( 'Dark', 'customtheme' ),
        ),
        'section' => 'customtheme_footer_options'
    ));
    $wp_customize->add_setting('customtheme_footer_layout', array(
        'default' => '3,3,3,3',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
        'validate_callback' => 'customtheme_validate_footer_layout'
    ));
    $wp_customize->add_control('customtheme_footer_layout', array(
        'type' => 'text',
        'label' => esc_html__( 'Footer Layout', 'customtheme' ),
        'section' => 'customtheme_footer_options'
    ));
}
add_action( 'customize_register', 'customtheme_customize_register' );

function customtheme_validate_footer_layout( $validity, $value) {
    if(!preg_match('/^([1-9]|1[012])(,([1-9]|1[012]))*$/', $value)) {
        $validity->add('invalid_footer_layout', esc_html__( 'Footer layout is invalid', 'customtheme' ));
    }
    return $validity;
}
function customtheme_sanitize_footer_bg( $input ) {
    $valid = array('light', 'dark');
    if( in_array($input, $valid, true) ) {
        return $input;
    }
    return 'dark';
}
function customtheme_sanitize_site_info( $input ) {
    $allowed = array('a' => array(
        'href' => array(),
        'title' => array()
    ));
    return wp_kses($input, $allowed);
}