<?php 
	function customtheme_register_menus() {
		register_nav_menus( array(
			'main-menu' => esc_html__('Main Menu','customtheme'),
			'footer-menu' => esc_html__('Footer Menu','customtheme')
		) );
	}
	add_action( 'init', 'customtheme_register_menus' );
