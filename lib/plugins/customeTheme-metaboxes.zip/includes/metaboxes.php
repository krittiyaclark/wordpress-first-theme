<?php
function customeTheme_add_meta_box() {
    add_meta_box( 
        'customeTheme_post_metabox', 
        'Post Settings', 
        'customeTheme_post_metabox_html', 
        'post', 
        'normal', 
        'default');
}
add_action( 'add_meta_boxes', 'customeTheme_add_meta_box' );
function customeTheme_post_metabox_html($post) {
    $subtitle = get_post_meta($post->ID, '_customeTheme_post_subtitle', true);
    $layout = get_post_meta($post->ID, '_customeTheme_post_layout', true);
    wp_nonce_field( 'customeTheme_update_post_metabox', 'customeTheme_update_post_nonce' );
    ?>
    <p>
        <label for="customeTheme_post_metabox_html"><?php esc_html_e( 'Post Subtitle', 'customeTheme-metaboxes' ); ?></label>
        <br />
        <input class="widefat" type="text" name="customeTheme_post_subtitle_field" id="customeTheme_post_metabox_html" value="<?php echo esc_attr( $subtitle ); ?>" />
    </p>
    <p>
        <label for="customeTheme_post_layout_field"><?php esc_html_e( 'Layout', 'customeTheme-metaboxes' ); ?></label>
        <select name="customeTheme_post_layout_field" id="customeTheme_post_layout_field" class="widefat">
            <option <?php selected( $layout, 'full' ); ?> value="full"><?php esc_html_e( 'Full Width', 'customeTheme-metaboxes' ); ?></option>
            <option <?php selected( $layout, 'sidebar' ); ?> value="sidebar"><?php esc_html_e( 'Post With Sidebar', 'customeTheme-metaboxes' ); ?></option>
        </select>
    </p>
    <?php
}
function customeTheme_save_post_metabox($post_id, $post) {
    $edit_cap = get_post_type_object( $post->post_type )->cap->edit_post;
    if( !current_user_can( $edit_cap, $post_id )) {
        return;
    }
    if( !isset( $_POST['customeTheme_update_post_nonce']) || !wp_verify_nonce( $_POST['customeTheme_update_post_nonce'], 'customeTheme_update_post_metabox' )) {
        return;
    }
    
    if(array_key_exists('customeTheme_post_subtitle_field', $_POST)) {
        update_post_meta( 
            $post_id, 
            '_customeTheme_post_subtitle', 
            sanitize_text_field($_POST['customeTheme_post_subtitle_field'])
        );
    }
    if(array_key_exists('customeTheme_post_layout_field', $_POST)) {
        update_post_meta( 
            $post_id, 
            '_customeTheme_post_layout', 
            sanitize_text_field($_POST['customeTheme_post_layout_field'])
        );
    }
}
add_action( 'save_post', 'customeTheme_save_post_metabox', 10, 2 );